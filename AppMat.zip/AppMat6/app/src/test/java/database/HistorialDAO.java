package database;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

    public class HistorialDAO {

        private DatabaseHelper dbHelper;
        private SQLiteDatabase database;

        public HistorialDAO(Context context) {
            dbHelper = new DatabaseHelper(context);
        }

        public void abrir() {
            database = dbHelper.getWritableDatabase();
        }

        public void cerrar() {
            dbHelper.close();
        }

        public void agregarEntrada(String accion, String fecha) {
            ContentValues values = new ContentValues();
            values.put("accion", accion);
            values.put("fecha", fecha);


            database.insert("historial", null, values);
        }
    }


