package com.example.appmat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.RadioGroup;
import android.widget.RadioButton;

import androidx.fragment.app.Fragment;

public class GraphingCalculatorFragment extends Fragment {

    private TextView resultadoTextView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.calculator_grafica_layout, container, false);

        resultadoTextView = view.findViewById(R.id.resultadoTextView);

        configurarListeners(view);

        return view;
    }

    private void configurarListeners(View view) {
        // Listener para el botón "="
        Button igualButton = view.findViewById(R.id.igualButton);
        igualButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "="
                resultadoTextView.setText("Botón '=' presionado");
            }
        });

        // Listener para el botón "sin"
        RadioButton sinButton = view.findViewById(R.id.sinButton);
        sinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "sin"
                resultadoTextView.setText("Botón 'sin' presionado");
            }
        });

        // Listener para el botón "cos"
        RadioButton cosButton = view.findViewById(R.id.cosButton);
        cosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "cos"
                resultadoTextView.setText("Botón 'cos' presionado");
            }
        });

        // Listener para el botón "tan"
        RadioButton tanButton = view.findViewById(R.id.tanButton);
        tanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "tan"
                resultadoTextView.setText("Botón 'tan' presionado");
            }
        });

        // Listener para el botón "hyp"
        RadioButton hypButton = view.findViewById(R.id.hypButton);
        hypButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "hyp"
                resultadoTextView.setText("Botón 'hyp' presionado");
            }
        });

        // Listener para el botón "sec"
        RadioButton secButton = view.findViewById(R.id.secButton);
        secButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "sec"
                resultadoTextView.setText("Botón 'sec' presionado");
            }
        });

        // Listener para el botón "csc"
        RadioButton cscButton = view.findViewById(R.id.cscButton);
        cscButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "csc"
                resultadoTextView.setText("Botón 'csc' presionado");
            }
        });

        // Listener para el botón "cot"
        RadioButton cotButton = view.findViewById(R.id.cotButton);
        cotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "cot"
                resultadoTextView.setText("Botón 'cot' presionado");
            }
        });

        // Listener para el botón ">"
        RadioButton mayorButton = view.findViewById(R.id.mayorButton);
        mayorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón ">"
                resultadoTextView.setText("Botón '>' presionado");
            }
        });

        // Listener para el botón "<"
        RadioButton menorButton = view.findViewById(R.id.menorButton);
        menorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "<"
                resultadoTextView.setText("Botón '<' presionado");
            }
        });

        // Listener para el botón ">="
        RadioButton mayorIgualButton = view.findViewById(R.id.mayorIgualButton);
        mayorIgualButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón ">="
                resultadoTextView.setText("Botón '>=' presionado");
            }
        });

        // Listener para el botón "<="
        RadioButton menorIgualButton = view.findViewById(R.id.menorIgualButton);
        menorIgualButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acción para el botón "<="
                resultadoTextView.setText("Botón '<=' presionado");
            }
        });

        // Puedes agregar más listeners para otros botones y elementos según sea necesario.
    }
}
