package com.example.appmat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class ProgramCalculatorFragment extends Fragment {

    private TextView resultadoTextView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.calculator_programadora_layout, container, false);

        resultadoTextView = view.findViewById(R.id.resultadoTextView);

        configurarListeners(view);

        return view;
    }

    private void configurarListeners(View view) {
        // Listener para los botones numéricos y letras
        int[] botonesNumericos = {
                R.id.boton1, R.id.boton2, R.id.boton3, R.id.boton4,
                R.id.boton5, R.id.boton6, R.id.boton7, R.id.boton8, R.id.boton9,
                R.id.botonA, R.id.botonB, R.id.botonC, R.id.botonD, R.id.botonE, R.id.botonF
        };

        for (int botonId : botonesNumericos) {
            Button boton = view.findViewById(botonId);
            boton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    resultadoTextView.setText("Botón " + ((Button) v).getText() + " presionado");
                }
            });
        }

        // Listener para el botón "("
        Button parentesisAbiertoButton = view.findViewById(R.id.parentesisAbiertoButton);
        parentesisAbiertoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón '(' presionado");
            }
        });

        // Listener para el botón ")"
        Button parentesisCerradoButton = view.findViewById(R.id.parentesisCerradoButton);
        parentesisCerradoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón ')' presionado");
            }
        });

        // Listener para el botón "CE"
        Button ceButton = view.findViewById(R.id.ceButton);
        ceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'CE' presionado");
            }
        });

        // Listener para el botón "<<" (desplazamiento a la izquierda)
        Button desplazamientoIzquierdaButton = view.findViewById(R.id.desplazamientoIzquierdoButton);
        desplazamientoIzquierdaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón '<<' presionado");
            }
        });

        // Listener para el botón ">>" (desplazamiento a la derecha)
        Button desplazamientoDerechaButton = view.findViewById(R.id.desplazamientoDerechaButton);
        desplazamientoDerechaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón '>>' presionado");
            }
        });

        // Listener para el botón "/" (división)
        Button divisionButton = view.findViewById(R.id.divisionButton);
        divisionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón '/' presionado");
            }
        });

        // Listener para el botón "+"
        Button sumaButton = view.findViewById(R.id.sumaButton);
        sumaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón '+' presionado");
            }
        });

        // Listener para el botón "-"
        Button restaButton = view.findViewById(R.id.restaButton);
        restaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón '-' presionado");
            }
        });

        // Listener para el botón "*"
        Button multiplicacionButton = view.findViewById(R.id.multiplicacionButton);
        multiplicacionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón '*' presionado");
            }
        });

        // Listener para el botón "AND"
        RadioButton andButton = view.findViewById(R.id.andButton);
        andButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'AND' presionado");
            }
        });

        // Listener para el botón "OR"
        RadioButton orButton = view.findViewById(R.id.orButton);
        orButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'OR' presionado");
            }
        });

        // Listener para el botón "NOT"
        RadioButton notButton = view.findViewById(R.id.notButton);
        notButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'NOT' presionado");
            }
        });

        // Listener para el botón "NAND"
        RadioButton nandButton = view.findViewById(R.id.nandButton);
        nandButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'NAND' presionado");
            }
        });

        // Listener para el botón "NOR"
        RadioButton norButton = view.findViewById(R.id.norButton);
        norButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'NOR' presionado");
            }
        });

        // Listener para el botón "XOR"
        RadioButton xorButton = view.findViewById(R.id.xorButton);
        xorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'XOR' presionado");
            }
        });

        // Listener para el botón "Aritmético"
        Button aritmeticoButton = view.findViewById(R.id.aritmeticoButton);
        aritmeticoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'Aritmético' presionado");
            }
        });

        // Listener para el botón "Lógico"
        Button logicoButton = view.findViewById(R.id.logicoButton);
        logicoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'Lógico' presionado");
            }
        });

        // Listener para el botón "Girar Circular"
        Button girarCircularButton = view.findViewById(R.id.girarCircularButton);
        girarCircularButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'Girar Circular' presionado");
            }
        });

        // Listener para el botón "Girar con Acarreo"
        Button girarAcarreoButton = view.findViewById(R.id.girarAcarreoButton);
        girarAcarreoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultadoTextView.setText("Botón 'Girar con Acarreo' presionado");
            }
        });
    }
}
