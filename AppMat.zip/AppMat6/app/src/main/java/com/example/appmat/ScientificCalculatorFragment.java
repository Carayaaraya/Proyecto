package com.example.appmat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class ScientificCalculatorFragment extends Fragment {

    private TextView resultadoTextView;
    private Button[] numeroButtons = new Button[10];
    private View view; // Declarar la variable view a nivel de clase

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.calculator_cientifica_layout, container, false); // Asignar el valor a la variable view

        resultadoTextView = view.findViewById(R.id.resultadoTextView);

        for (int i = 0; i < 10; i++) {
            int buttonId = getResources().getIdentifier("numeroButton" + i, "id", requireActivity().getPackageName());
            numeroButtons[i] = view.findViewById(buttonId);
        }

        configurarListeners();

        return view;
    }

    private void configurarListeners() {
        // Listener para el botón "="
        Button igualButton = view.findViewById(R.id.igualButton);
        igualButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // Obtén el texto actual en resultadoTextView
                    String expresion = resultadoTextView.getText().toString();
                    if (!expresion.isEmpty()) {
                        // Evalúa la expresión matemática y muestra el resultado
                        double resultado = evaluarExpresion(expresion);
                        resultadoTextView.setText(String.valueOf(resultado));
                    }
                } catch (Exception e) {
                    // Manejar errores al evaluar la expresión
                    resultadoTextView.setText("Error");
                }
            }

            private double evaluarExpresion(String expresion) {
                return 0;
            }
        });

        // Listeners para los botones de números
        for (int i = 0; i < 10; i++) {
            final int numero = i;
            numeroButtons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Obtén el número que representa el botón
                    String numeroPresionado = String.valueOf(numero);

                    // Obtén el texto actual en resultadoTextView
                    String expresion = resultadoTextView.getText().toString();

                    // Agrega el número presionado a la expresión existente
                    expresion = expresion + numeroPresionado;

                    // Actualiza el contenido de resultadoTextView
                    resultadoTextView.setText(expresion);
                }
            });
        }


    }
}

