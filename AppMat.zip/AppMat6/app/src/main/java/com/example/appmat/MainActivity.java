package com.example.appmat;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private TabLayout tabLayout;
    private CalculatorPagerAdapter calculatorPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.nav_view2); // Cambia 'nav_view2' a 'viewPager' para que coincida con el ID de tu archivo XML
        tabLayout = findViewById(R.id.nav_view); // Cambia 'nav_view' a 'tabLayout' para que coincida con el ID de tu archivo XML

        // Crear un adaptador personalizado para gestionar las pestañas
        calculatorPagerAdapter = new CalculatorPagerAdapter(getSupportFragmentManager());

        // Agregar fragmentos de calculadoras al adaptador
        calculatorPagerAdapter.addFragment(new StandardCalculatorFragment(), "Estándar");
        calculatorPagerAdapter.addFragment(new ScientificCalculatorFragment(), "Científica");
        calculatorPagerAdapter.addFragment(new GraphingCalculatorFragment(), "Gráfica");
        calculatorPagerAdapter.addFragment(new ProgramCalculatorFragment(), "Programadora");
        calculatorPagerAdapter.addFragment(new DayCalculatorFragment(), "Fecha");
        // Agregar más calculadoras según sea necesario

        // Configurar el adaptador para el ViewPager
        viewPager.setAdapter(calculatorPagerAdapter);

        // Conectar el ViewPager al TabLayout
        tabLayout.setupWithViewPager(viewPager);
    }
}

