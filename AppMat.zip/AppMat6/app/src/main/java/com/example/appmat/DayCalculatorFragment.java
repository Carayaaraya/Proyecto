package com.example.appmat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class DayCalculatorFragment extends Fragment {

    private TextView fechaTextView;
    private Button calcularButton;
    private Button diaButton;
    private Button mesButton;
    private Button anioButton;
    private Button[] numeroButtons = new Button[10];

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.calculator_calculo_de_fecha_layout, container, false);

        fechaTextView = view.findViewById(R.id.fechaTextView);
        calcularButton = view.findViewById(R.id.calcularButton);
        diaButton = view.findViewById(R.id.diaButton);
        mesButton = view.findViewById(R.id.mesButton);
        anioButton = view.findViewById(R.id.anioButton);

        for (int i = 0; i < 10; i++) {
            int buttonId = getResources().getIdentifier("numeroButton" + i, "id", requireActivity().getPackageName());
            numeroButtons[i] = view.findViewById(buttonId);
        }

        configurarListeners();

        return view;
    }

    private void configurarListeners() {
        // Listener para el botón de cálculo
        calcularButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aquí debes implementar la lógica para calcular la fecha
                // Puedes obtener los valores ingresados en los TextViews, realizar los cálculos y mostrar el resultado en fechaTextView.
            }
        });

        // Listeners para los botones de números
        for (int i = 0; i < 10; i++) {
            final int numero = i;
            numeroButtons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        // Obtener los valores ingresados en los campos de día, mes y año
                        int dia = Integer.parseInt(diaButton.getText().toString());
                        int mes = Integer.parseInt(mesButton.getText().toString());
                        int anio = Integer.parseInt(anioButton.getText().toString());

                        // Realizar los cálculos necesarios, por ejemplo, sumar 1 al día
                        dia++;

                        // Verificar si el día supera el límite del mes (suponemos que todos los meses tienen 31 días)
                        if (dia > 31) {
                            dia = 1;
                            mes++;
                            // Verificar si el mes supera el límite de 12 (diciembre)
                            if (mes > 12) {
                                mes = 1;
                                anio++;
                            }
                        }

                        // Actualizar el TextView con la nueva fecha
                        fechaTextView.setText(dia + "/" + mes + "/" + anio);
                    } catch (NumberFormatException e) {
                        // Manejar el error si los valores no son números válidos
                        fechaTextView.setText("Valores no válidos");
                    }
                }
            });

        }
            }

        }

