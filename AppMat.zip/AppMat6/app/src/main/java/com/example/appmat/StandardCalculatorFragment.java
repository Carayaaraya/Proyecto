package com.example.appmat;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;



import androidx.fragment.app.Fragment;

import java.util.Stack;

public class StandardCalculatorFragment extends Fragment {

    private TextView resultadoTextView;
    private StringBuilder inputStringBuilder = new StringBuilder();
    private boolean isResultShown = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.calculator_standard_layout, container, false);

        resultadoTextView = view.findViewById(R.id.resultadoTextView);

        configurarListeners(view);

        return view;
    }

    private void configurarListeners(View view) {
        int[] botonesNumericos = {
                R.id.boton0, R.id.boton1, R.id.boton2, R.id.boton3,
                R.id.boton4, R.id.boton5, R.id.boton6, R.id.boton7,
                R.id.boton8, R.id.boton9
        };

        for (int botonId : botonesNumericos) {
            Button boton = view.findViewById(botonId);
            boton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isResultShown) {
                        resultadoTextView.setText("");
                        inputStringBuilder.setLength(0);
                        isResultShown = false;
                    }
                    String textoBoton = ((Button) v).getText().toString();
                    inputStringBuilder.append(textoBoton);
                    resultadoTextView.append(textoBoton);
                }
            });
        }

        // Listener para el botón de suma
        Button sumaButton = view.findViewById(R.id.botonSuma);
        sumaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isResultShown) {
                    isResultShown = false;
                    resultadoTextView.setText(inputStringBuilder);
                }
                inputStringBuilder.append("+");
                resultadoTextView.append("+");
            }
        });

        // Listener para el botón de resta
        Button restaButton = view.findViewById(R.id.botonResta);
        restaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isResultShown) {
                    isResultShown = false;
                    resultadoTextView.setText(inputStringBuilder);
                }
                inputStringBuilder.append("-");
                resultadoTextView.append("-");
            }
        });

        // Listener para el botón igual
        Button igualButton = view.findViewById(R.id.botonResultado);
        igualButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String input = inputStringBuilder.toString();
                    double resultado = evaluarExpresion(input);
                    resultadoTextView.setText(String.valueOf(resultado));
                    isResultShown = true;
                } catch (Exception e) {
                    resultadoTextView.setText("Error");
                }
            }
        });

        // Listener para el botón de multiplicación
        Button multiplicacionButton = view.findViewById(R.id.botonMultiplicacion);
        multiplicacionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isResultShown) {
                    isResultShown = false;
                    resultadoTextView.setText(inputStringBuilder);
                }
                inputStringBuilder.append("*");
                resultadoTextView.append("*");
            }
        });

        // Listener para el botón de división
        Button divisionButton = view.findViewById(R.id.botonDivision);
        divisionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isResultShown) {
                    isResultShown = false;
                    resultadoTextView.setText(inputStringBuilder);
                }
                inputStringBuilder.append("/");
                resultadoTextView.append("/");
            }
        });

        // Puedes agregar más listeners para los otros botones y operaciones según sea necesario.
    }

    // Evaluar la expresión matemática
    private double evaluarExpresion(String expresion) {
        try {
            Stack<Double> numeros = new Stack<>();
            Stack<Character> operadores = new Stack<>();

            for (int i = 0; i < expresion.length(); i++) {
                char c = expresion.charAt(i);

                if (Character.isDigit(c)) {
                    StringBuilder numeroStr = new StringBuilder();
                    while (i < expresion.length() && (Character.isDigit(expresion.charAt(i)) || expresion.charAt(i) == '.')) {
                        numeroStr.append(expresion.charAt(i));
                        i++;
                    }
                    i--;
                    double numero = Double.parseDouble(numeroStr.toString());
                    numeros.push(numero);
                } else if (c == '(') {
                    operadores.push(c);
                } else if (c == ')') {
                    while (!operadores.isEmpty() && operadores.peek() != '(') {
                        calcular(numeros, operadores);
                    }
                    operadores.pop(); // Sacar el paréntesis abierto
                } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                    while (!operadores.isEmpty() && tienePrecedenciaMenor(c, operadores.peek())) {
                        calcular(numeros, operadores);
                    }
                    operadores.push(c);
                }
            }

            while (!operadores.isEmpty()) {
                calcular(numeros, operadores);
            }

            return numeros.pop();
        } catch (Exception e) {
            e.printStackTrace();
            return 0.0; // Manejo de errores básico; puedes personalizarlo según tus necesidades.
        }
    }

    private boolean tienePrecedenciaMenor(char operador1, char operador2) {
        if ((operador1 == '*' || operador1 == '/') && (operador2 == '+' || operador2 == '-')) {
            return true;
        }
        return false;
    }

    private void calcular(Stack<Double> numeros, Stack<Character> operadores) {
        double b = numeros.pop();
        double a = numeros.pop();
        char operador = operadores.pop();
        double resultado = 0.0;
        switch (operador) {
            case '+':
                resultado = a + b;
                break;
            case '-':
                resultado = a - b;
                break;
            case '*':
                resultado = a * b;
                break;
            case '/':
                if (b != 0) {
                    resultado = a / b;
                } else {
                    // Manejo de división por cero
                    throw new ArithmeticException("División por cero");
                }
                break;
        }
        numeros.push(resultado);
    }
}
