package com.example.appmat.ui.home;// Importa las clases necesarias
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    // LiveData para el texto que se mostrará en el fragmento
    private MutableLiveData<String> textLiveData;

    public HomeViewModel() {
        // Inicializa el LiveData
        textLiveData = new MutableLiveData<>();
        // Establece un valor predeterminado
        textLiveData.setValue("¡Hola desde HomeViewModel!");
    }

    // Método para obtener el LiveData del texto
    public LiveData<String> getText() {
        return textLiveData;
    }

    // Puedes agregar más métodos y lógica según sea necesario

}
